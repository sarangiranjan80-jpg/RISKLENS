import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
import numpy as np, pandas as pd, pytest
from risklens.risk.metrics import var_es,max_drawdown,annualized_volatility
from risklens.models.merton import simulate_merton
from risklens.models.heston import simulate_heston
from risklens.models.hawkes import hawkes_is_stable,hawkes_intensity
from risklens.models.pca_absorption import absorption_ratio
from risklens.simulation.monte_carlo import simulate_gbm
from risklens.portfolio.engine import portfolio_weights,portfolio_returns,align_fx
from risklens.security import mask_secret,redact
def test_var_es_loss_signs():
    v,e=var_es(np.array([.1,.02,-.03,-.08,-.01]),.8)
    assert v>=0 and e>=v
def test_drawdown():
    assert max_drawdown([100,120,90,110])==pytest.approx(-.25)
def test_merton_reproducible():
    assert np.allclose(simulate_merton(100,.05,.2,5,100,seed=2),simulate_merton(100,.05,.2,5,100,seed=2))
def test_heston_shape_positive():
    x=simulate_heston(100,.05,.04,2,.04,.3,-.6,5,100,seed=1)
    assert x.shape==(100,5) and (x>0).all()
def test_hawkes_stability():
    assert hawkes_is_stable(.2,1) and not hawkes_is_stable(1,1)
    with pytest.raises(ValueError): hawkes_intensity([1,2],1,2,1)
def test_absorption_range():
    x=np.random.default_rng(2).normal(size=(100,4))
    a=absorption_ratio(x,window=30)
    assert len(a)==71 and ((a>=0)&(a<=1)).all()
def test_mc_reproducible():
    r=np.random.default_rng(1).normal(0,.01,500)
    assert np.allclose(simulate_gbm(100,r,5,1000,42),simulate_gbm(100,r,5,1000,42))
def test_portfolio_weights():
    x=portfolio_weights([{"ticker":"A","units":2,"price":10},{"ticker":"B","units":1,"price":20}])
    assert x.weight.sum()==pytest.approx(1)
def test_mask_redaction():
    assert "abc" not in mask_secret("secretabc")
    assert "secretabc" not in redact("key=secretabc",["secretabc"])
def test_fx_missing():
    with pytest.raises(ValueError): align_fx(pd.Series([1,None]),pd.Series([2,3]))
