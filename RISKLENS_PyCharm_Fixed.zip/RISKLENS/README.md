# RISKLENS — quantitative market & portfolio risk

A Python 3.11+ Streamlit project with a dark financial-terminal UI, market history via yfinance, demo mode, historical risk metrics, a reproducible Monte Carlo baseline, editable portfolio holdings, RSS news, provider connection tests, and modular model/portfolio/backtesting code.

## Run in PyCharm

1. Install Python 3.11 or newer and open this folder as a PyCharm project.
2. Create a virtual environment (`Settings → Project → Python Interpreter`).
3. In PyCharm's terminal:

   ```bash
   python -m pip install --upgrade pip
   pip install -r requirements.txt
   streamlit run app.py
   ```

4. Open the local URL printed by Streamlit (usually `http://localhost:8501`).
5. The app starts without API credentials. Demo mode is ON by default and uses synthetic data, explicitly labelled as demo data.

## Live historical prices

Turn off **Use demo data** in the sidebar. The app attempts to download the selected ticker from Yahoo Finance through yfinance. Network access, provider availability, ticker support and rate limits can affect results. This does not mean Finnhub or Alpha Vantage is connected.

For India, enter a ticker such as `RELIANCE` with NSE selected (normalizes to `.NS`) or select BSE (normalizes to `.BO`). For US, enter symbols such as `AAPL` or `NVDA`.

## API keys

Copy `.env.example` to `.env` and set `FINNHUB_API_KEY` and/or `ALPHA_VANTAGE_API_KEY`. Never commit `.env`. Alternatively use your deployment's secret manager or enter keys in **API & Data Settings**; session-entered keys are not persisted. The settings page tests real endpoints and displays provider-specific errors. Keys are never intentionally printed in the UI or logged. Avoid sharing screenshots of credential inputs.

## Tests

```bash
pytest -q
```

Run from the project root. Tests cover core risk signs, reproducibility, positivity, Hawkes stability, PCA absorption, portfolio weights, FX missingness and secret redaction.

## What is implemented and what is not

Implemented: provider-independent ticker normalization and price validation, Yahoo Finance download path, deterministic synthetic demo prices, annualized return/volatility, drawdown, Sharpe, historical VaR/ES, GBM Monte Carlo, Merton jump diffusion, Heston simulation, a basic Bates simulation overlay, Gaussian-mixture regime estimation with transition counts, Student-t dependence transform, exponential Hawkes intensity/stability check, PCA absorption ratio, RSS ingestion, long-only minimum-variance optimizer, FX alignment guard, and walk-forward historical VaR checks.

Important limitations: this is a functional research starter, not a validated production risk platform. Advanced model calibration (especially Bates), FinBERT inference, macro data, multi-asset contagion scoring, sophisticated ES-aware constraints, provider-backed news APIs, exchange-specific trading calendars, robust FX sourcing, rate-limit coordination and all 11 pages as standalone feature-complete screens remain incomplete. The advanced modules are research utilities, not evidence of model superiority. The Streamlit page navigation uses a shared main dashboard; some named `pages/` entries are routing stubs. No trades are executed.

## Model and metric conventions

- Returns are simple daily returns for historical metrics.
- Annualization uses 252 trading sessions.
- VaR and ES are positive loss magnitudes. Historical VaR is the quantile of returns at `1-confidence`; ES is the average return in that tail, negated.
- “5-Day Worst-Case Bleed” is an approximate square-root-of-time-scaled 5-day 95% ES estimate, not an absolute maximum or guarantee.
- The Monte Carlo baseline uses a simple Gaussian/GBM-style daily return model estimated from the selected historical series. It does not blend jump, Heston, regime and Hawkes models into one simulation.
- Synthetic demo prices are for interface exploration and must not be interpreted as real market data.
- Market Weather uses a transparent realized-volatility heuristic. No value is called a crash probability.
- Bates calibration intentionally raises `NotImplementedError` rather than pretending a fitted calibration exists.
- FinBERT is not loaded automatically. News sentiment does not modify jump intensities.
- Backtesting is walk-forward and avoids using the current observation in its own training window, but more formal ES scoring, confidence intervals, regime diagnostics and statistical tests are still needed.

## Troubleshooting

- `ModuleNotFoundError`: confirm the PyCharm interpreter is the environment where `pip install -r requirements.txt` ran.
- No data: check ticker suffix, network access and Yahoo Finance availability; switch to demo mode to explore the interface.
- Provider connection errors: verify key permissions and quota. A successful test only verifies that provider endpoint, not all product features.
- Slow simulation: reduce Monte Carlo paths or horizon.
- Tests: run `python -m pytest -q` from project root.


## Windows / PyCharm launch and navigation note

Run from the project root (the folder containing `app.py`):

```powershell
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

RISKLENS uses the integrated navigation selector inside `app.py`. The `pages/` directory intentionally contains no Streamlit page scripts; adding placeholder `.py` files there makes Streamlit show separate screens that do not include the integrated controls. Use the RISKLENS navigation selector in the app sidebar to open Overview, Stress Testing, and the other implemented sections.

If an older copy is already running, stop it with `Ctrl+C` in its terminal, replace the project with this corrected version, and launch the command above again.
