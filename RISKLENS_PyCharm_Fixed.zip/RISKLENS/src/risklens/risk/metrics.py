import numpy as np
def clean_returns(returns):
    x=np.asarray(returns,dtype=float).ravel()
    return x[np.isfinite(x)]
def var_es(returns, confidence=0.95):
    x=clean_returns(returns)
    if len(x)<2: raise ValueError("At least two observations are required.")
    q=float(np.quantile(x,1-confidence))
    tail=x[x<=q]
    return max(0.0,-q), max(0.0,-float(tail.mean()) if len(tail) else -q)
def historical_var_es(returns, confidence=.95): return var_es(returns, confidence)
def max_drawdown(prices):
    p=np.asarray(prices,dtype=float); p=p[np.isfinite(p)]
    if not len(p) or np.any(p<=0): return float("nan")
    return float(np.min(p/np.maximum.accumulate(p)-1))
def annualized_volatility(returns, periods=252):
    x=clean_returns(returns)
    return float(np.std(x,ddof=1)*np.sqrt(periods)) if len(x)>1 else float("nan")
def annualized_return(returns, periods=252):
    x=clean_returns(returns)
    if not len(x): return float("nan")
    return float(np.prod(1+x)**(periods/len(x))-1)
def sharpe_ratio(returns, risk_free_annual=0.0, periods=252):
    x=clean_returns(returns)
    if len(x)<2: return float("nan")
    excess=x-risk_free_annual/periods
    vol=np.std(excess,ddof=1)
    return float(np.mean(excess)/vol*np.sqrt(periods)) if vol>0 else float("nan")
