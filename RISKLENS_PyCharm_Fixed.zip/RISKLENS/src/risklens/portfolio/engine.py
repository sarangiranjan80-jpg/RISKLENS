import numpy as np
import pandas as pd
def portfolio_weights(holdings):
    df=pd.DataFrame(holdings).copy()
    if "value" not in df: df["value"]=df["units"].astype(float)*df["price"].astype(float)
    total=df["value"].sum()
    df["weight"]=df["value"]/total if total>0 else 0.0
    return df
def portfolio_returns(asset_returns, weights):
    r=np.asarray(asset_returns,dtype=float); w=np.asarray(weights,dtype=float)
    if r.ndim!=2 or r.shape[1]!=len(w): raise ValueError("Return columns must match weights.")
    if not np.isclose(w.sum(),1,atol=1e-5): raise ValueError("Weights must sum to one.")
    return r@w
def optimize_min_variance(returns, max_weight=1.0):
    from scipy.optimize import minimize
    x=np.asarray(returns,dtype=float); cov=np.cov(x,rowvar=False); n=x.shape[1]
    result=minimize(lambda w: float(w@cov@w), np.ones(n)/n, method="SLSQP",
        bounds=[(0,max_weight)]*n, constraints=[{"type":"eq","fun":lambda w:w.sum()-1}],
        options={"maxiter":1000,"ftol":1e-12})
    if not result.success: raise ValueError(f"Optimization failed: {result.message}")
    return result.x
def align_fx(prices, fx):
    if prices.isna().any() or fx.isna().any():
        raise ValueError("FX alignment has missing source observations; fill only after validating the provider's calendar policy.")
    joined=pd.concat([prices.rename("price"),fx.rename("fx")],axis=1).sort_index()
    if joined[["price","fx"]].isna().any().any(): raise ValueError("FX alignment has missing values; cannot combine currencies safely.")
    return joined["price"]*joined["fx"]
