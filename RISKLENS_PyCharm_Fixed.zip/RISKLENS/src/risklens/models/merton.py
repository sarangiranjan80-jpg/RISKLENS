import numpy as np
def simulate_merton(s0, mu, sigma, horizon, paths=10000, steps=None, jump_intensity=.1, jump_mean=-.08, jump_sigma=.15, seed=None):
    if s0<=0 or sigma<0 or horizon<1 or paths<1 or jump_intensity<0: raise ValueError("Invalid simulation parameters.")
    rng=np.random.default_rng(seed); n=steps or horizon
    dt=1/252; z=rng.normal(size=(paths,n)); counts=rng.poisson(jump_intensity*dt,size=(paths,n))
    jumps=rng.normal(jump_mean,jump_sigma,size=(paths,n))*counts
    compensator=jump_intensity*(np.exp(jump_mean+jump_sigma**2/2)-1)
    logret=(mu-.5*sigma**2-compensator)*dt+sigma*np.sqrt(dt)*z+jumps
    return s0*np.exp(np.cumsum(logret,axis=1))
