import numpy as np
def absorption_ratio(returns, window=60, components=1):
    x=np.asarray(returns,dtype=float)
    if x.ndim==1: x=x[:,None]
    if x.shape[0]<window or x.shape[1]<1: raise ValueError("Not enough aligned observations for absorption ratio.")
    result=[]
    for end in range(window,x.shape[0]+1):
        block=x[end-window:end]
        cov=np.cov(block,rowvar=False)
        cov=np.atleast_2d(cov)
        eig=np.linalg.eigvalsh(cov); total=eig.sum()
        result.append(float(np.sort(eig)[::-1][:components].sum()/total) if total>0 else float("nan"))
    return np.array(result)
