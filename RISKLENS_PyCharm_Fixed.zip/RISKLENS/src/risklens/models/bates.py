from .heston import simulate_heston
from .merton import simulate_merton
def simulate_bates(s0, mu, v0, kappa, theta, xi, rho, horizon, paths=10000, jump_intensity=.05, jump_mean=-.05, jump_sigma=.1, seed=None):
    # Explicit baseline composition: Heston diffusion with an independent Merton-style jump overlay.
    import numpy as np
    h=simulate_heston(s0,mu,v0,kappa,theta,xi,rho,horizon,paths,seed)
    rng=np.random.default_rng(seed); dt=1/252
    counts=rng.poisson(jump_intensity*dt,size=(paths,horizon))
    sizes=rng.normal(jump_mean,jump_sigma,size=(paths,horizon))*counts
    return h*np.exp(np.cumsum(sizes,axis=1))
def calibrate_bates(*args, **kwargs):
    raise NotImplementedError("Bates calibration is not implemented in this starter; use documented parameter sensitivity, not fitted claims.")
