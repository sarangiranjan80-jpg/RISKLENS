import numpy as np
from scipy.stats import rankdata, t
def fit_t_copula(data, df=5):
    x=np.asarray(data,dtype=float)
    if x.ndim!=2 or x.shape[0]<10: raise ValueError("Need at least 10 rows of multivariate returns.")
    u=np.column_stack([rankdata(x[:,i])/(len(x)+1) for i in range(x.shape[1])])
    z=t.ppf(np.clip(u,1e-6,1-1e-6),df=df)
    corr=np.corrcoef(z,rowvar=False)
    corr=np.nan_to_num(corr,nan=0.0); np.fill_diagonal(corr,1)
    return {"df":float(df),"correlation":corr}
def simulate_t_copula(fit, paths=10000, seed=None):
    rng=np.random.default_rng(seed); corr=fit["correlation"]; df=fit["df"]
    z=rng.multivariate_normal(np.zeros(corr.shape[0]),corr,size=paths)
    chi=rng.chisquare(df,size=paths)
    return z/np.sqrt(chi[:,None]/df)
