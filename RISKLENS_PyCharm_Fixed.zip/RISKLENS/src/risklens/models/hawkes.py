import numpy as np
def hawkes_intensity(times, mu, alpha, beta):
    if mu<=0 or alpha<0 or beta<=0 or alpha>=beta: raise ValueError("Require mu>0, alpha>=0, beta>alpha for stability.")
    ts=np.sort(np.asarray(times,dtype=float)); out=np.empty(len(ts)); excitation=0.; last=0.
    for i,t in enumerate(ts):
        excitation*=np.exp(-beta*(t-last)); out[i]=mu+excitation
        excitation+=alpha; last=t
    return out
def hawkes_is_stable(alpha,beta): return bool(0<=alpha<beta and beta>0)
