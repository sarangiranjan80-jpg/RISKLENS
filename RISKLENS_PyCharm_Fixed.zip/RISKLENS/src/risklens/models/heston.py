import numpy as np
def simulate_heston(s0, mu, v0, kappa, theta, xi, rho, horizon, paths=10000, seed=None):
    if s0<=0 or min(v0,kappa,theta,xi)<0 or not -1<=rho<=1 or horizon<1: raise ValueError("Invalid Heston parameters.")
    rng=np.random.default_rng(seed); dt=1/252
    price=np.full(paths,float(s0)); v=np.full(paths,float(v0)); out=np.empty((paths,horizon))
    for t in range(horizon):
        z1=rng.normal(size=paths); z2=rho*z1+np.sqrt(max(0,1-rho*rho))*rng.normal(size=paths)
        vp=np.maximum(v,0); price*=np.exp((mu-.5*vp)*dt+np.sqrt(vp*dt)*z1)
        v=np.maximum(v+kappa*(theta-vp)*dt+xi*np.sqrt(vp*dt)*z2,0)
        out[:,t]=price
    return out
