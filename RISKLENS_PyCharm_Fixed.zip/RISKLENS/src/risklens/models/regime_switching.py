import numpy as np
def fit_regimes(returns, n_regimes=2, seed=7):
    from sklearn.mixture import GaussianMixture
    x=np.asarray(returns,dtype=float).reshape(-1,1)
    x=x[np.isfinite(x).ravel()]
    if len(x)<max(30,n_regimes*10): raise ValueError("Insufficient observations for regime estimation.")
    model=GaussianMixture(n_components=n_regimes,random_state=seed,n_init=3).fit(x)
    labels=model.predict(x); means=model.means_.ravel(); order=np.argsort(means)
    mapping={int(old):int(new) for new,old in enumerate(order)}
    labels=np.array([mapping[int(v)] for v in labels])
    trans=np.ones((n_regimes,n_regimes))
    for a,b in zip(labels[:-1],labels[1:]): trans[a,b]+=1
    trans/=trans.sum(axis=1,keepdims=True)
    return {"labels":labels,"means":means[order],"stds":np.sqrt(model.covariances_.reshape(-1)[order]),"transition":trans,"model":model}
