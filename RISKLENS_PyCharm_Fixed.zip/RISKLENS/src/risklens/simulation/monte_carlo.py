import numpy as np
def simulate_gbm(s0, returns, horizon=5, paths=10000, seed=42, batch_size=2000):
    x=np.asarray(returns,dtype=float); x=x[np.isfinite(x)]
    if s0<=0 or len(x)<2 or not 1<=horizon<=30 or paths<100: raise ValueError("Invalid price, return history, horizon, or path count.")
    mu=float(x.mean()); sigma=float(x.std(ddof=1)); rng=np.random.default_rng(seed)
    out=np.empty((paths,horizon)); cursor=0
    while cursor<paths:
        n=min(batch_size,paths-cursor)
        z=rng.normal(size=(n,horizon))
        daily=(mu-.5*sigma*sigma)+sigma*z
        out[cursor:cursor+n]=s0*np.exp(np.cumsum(daily,axis=1))
        cursor+=n
    return out
