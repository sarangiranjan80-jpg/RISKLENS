import os, re
from dotenv import load_dotenv
load_dotenv()
def get_secret(name: str, session_value: str | None = None) -> str | None:
    value = session_value or os.getenv(name)
    return value.strip() if value and value.strip() else None
def mask_secret(value: str | None) -> str:
    if not value: return "Not configured"
    return "•" * max(4, min(16, len(value)-2)) + value[-2:]
def redact(text: str, secrets: list[str] | None = None) -> str:
    out = str(text)
    for secret in secrets or []:
        if secret: out = out.replace(secret, "[REDACTED]")
    out = re.sub(r'(?i)(api[_-]?key|token|secret)=([^&\s]+)', r'\1=[REDACTED]', out)
    return out
