from __future__ import annotations
import time
import numpy as np
import pandas as pd
import requests
import yfinance as yf
from ..security import get_secret
DEMO = False
def normalize_ticker(ticker: str, exchange: str = "US") -> str:
    t = ticker.strip().upper()
    if not t: raise ValueError("Enter a ticker symbol.")
    if exchange.upper() in {"NSE", "BSE", "INDIA"} and "." not in t:
        t += ".NS" if exchange.upper() != "BSE" else ".BO"
    return t
def validate_prices(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty: raise ValueError("No price observations returned.")
    frame = df.copy()
    if isinstance(frame.columns, pd.MultiIndex): frame.columns = frame.columns.get_level_values(0)
    col = "Adj Close" if "Adj Close" in frame else "Close" if "Close" in frame else None
    if col is None: raise ValueError("Provider returned no Close/Adj Close column.")
    frame = frame[~frame.index.duplicated(keep="last")].sort_index()
    frame[col] = pd.to_numeric(frame[col], errors="coerce")
    frame = frame.loc[frame[col].notna() & (frame[col] > 0)]
    if len(frame) < 2: raise ValueError("At least two valid prices are required.")
    frame["Price"] = frame[col]
    frame["Return"] = frame["Price"].pct_change()
    return frame.dropna(subset=["Price"])
def historical_prices(ticker: str, start, end, timeout: int = 10) -> tuple[pd.DataFrame, str]:
    # yfinance does not expose a reliable timeout on every path; bounded download period and errors are handled.
    data = yf.download(ticker, start=start, end=end, auto_adjust=False, progress=False, threads=False, timeout=timeout)
    return validate_prices(data), "Yahoo Finance (yfinance)"
def demo_prices(ticker: str, days: int = 1500, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range(end=pd.Timestamp.today().normalize(), periods=days)
    returns = rng.normal(0.00035, 0.018, days)
    price = 100 * np.exp(np.cumsum(returns))
    return pd.DataFrame({"Price": price, "Return": pd.Series(price).pct_change().to_numpy()}, index=dates).dropna()
def safe_download(ticker, start, end, demo=False):
    if demo: return demo_prices(ticker), "DEMO DATA — synthetic, not market observations"
    return historical_prices(ticker, start, end)
def test_finnhub(key: str, timeout=8) -> tuple[bool,str]:
    try:
        r=requests.get("https://finnhub.io/api/v1/stock/profile2", params={"symbol":"AAPL","token":key}, timeout=timeout)
        if r.status_code == 401: return False, "Finnhub rejected the key (401)."
        if r.status_code == 429: return False, "Finnhub quota/rate limit reached (429)."
        r.raise_for_status()
        if not r.json(): return False, "Connected, but the test symbol returned no profile data."
        return True, "Finnhub connection verified."
    except requests.RequestException as e: return False, f"Connection failed: {type(e).__name__}"
def test_alpha_vantage(key: str, timeout=8) -> tuple[bool,str]:
    try:
        r=requests.get("https://www.alphavantage.co/query", params={"function":"GLOBAL_QUOTE","symbol":"IBM","apikey":key}, timeout=timeout)
        r.raise_for_status(); data=r.json()
        if "Error Message" in data: return False, "Alpha Vantage rejected the request or symbol."
        if "Note" in data or "Information" in data: return False, "Alpha Vantage rate limit or provider notice."
        if "Global Quote" not in data: return False, "No quote returned; verify key and provider access."
        return True, "Alpha Vantage connection verified."
    except requests.RequestException as e: return False, f"Connection failed: {type(e).__name__}"
