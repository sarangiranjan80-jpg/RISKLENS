from pathlib import Path
from pydantic import BaseModel, Field
ROOT = Path(__file__).resolve().parents[2]
DATA_DIR = ROOT / "data"
DEMO_DIR = DATA_DIR / "demo"
class AppConfig(BaseModel):
    default_paths: int = Field(default=10_000, ge=100, le=200_000)
    default_horizon: int = Field(default=5, ge=1, le=30)
    cache_seconds: int = Field(default=900, ge=0, le=86400)
    request_timeout: float = Field(default=8.0, ge=1, le=30)
