from . import *
def data_label(source): return "DEMO" if str(source).startswith("DEMO") else "Provider data"
