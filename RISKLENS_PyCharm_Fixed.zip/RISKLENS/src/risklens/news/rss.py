import feedparser
def fetch_rss(urls):
    items=[]; errors=[]
    for url in urls:
        try:
            feed=feedparser.parse(url)
            for e in feed.entries[:30]:
                items.append({"title":e.get("title","(untitled)"),"source":feed.feed.get("title",url),
                    "link":e.get("link",""),"published":e.get("published",e.get("updated","")),
                    "summary":e.get("summary",""),"sentiment":"Unavailable","confidence":None})
        except Exception as exc: errors.append(f"{url}: {type(exc).__name__}")
    return items,errors
