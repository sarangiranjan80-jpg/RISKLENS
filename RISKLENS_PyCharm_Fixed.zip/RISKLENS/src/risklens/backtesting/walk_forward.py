import numpy as np
def walk_forward_var(returns, train_window=252, confidence=.95):
    x=np.asarray(returns,dtype=float); x=x[np.isfinite(x)]
    if len(x)<=train_window: raise ValueError("Need more observations than the training window.")
    forecasts=[]; realized=[]
    for i in range(train_window,len(x)):
        hist=x[i-train_window:i]
        forecasts.append(-float(np.quantile(hist,1-confidence)))
        realized.append(-float(x[i]))
    return {"var":np.asarray(forecasts),"loss":np.asarray(realized),"exceedances":int(np.sum(np.asarray(realized)>np.asarray(forecasts)))}
