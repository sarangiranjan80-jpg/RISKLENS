# Navigation note

RISKLENS uses a single Streamlit entry point (`app.py`) with an internal sidebar navigation selector. Do not add placeholder `.py` pages here: Streamlit automatically exposes files in this folder as separate pages, which bypasses the integrated controls and creates blank placeholder screens.
