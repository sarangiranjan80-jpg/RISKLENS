from pathlib import Path
import sys, os, datetime as dt
sys.path.insert(0, str(Path(__file__).parent / "src"))
import numpy as np, pandas as pd, streamlit as st, plotly.graph_objects as go, plotly.express as px
from risklens.data.providers import normalize_ticker, safe_download, test_finnhub, test_alpha_vantage
from risklens.risk.metrics import var_es, annualized_volatility, annualized_return, max_drawdown, sharpe_ratio
from risklens.simulation.monte_carlo import simulate_gbm
from risklens.portfolio.engine import portfolio_weights
from risklens.security import get_secret, mask_secret
from risklens.news.rss import fetch_rss

st.set_page_config(page_title="RISKLENS | Quantitative Risk", page_icon="◈", layout="wide")
st.markdown('''
<style>
:root{color-scheme:dark} .stApp{background:#080e18;color:#e6edf7}
[data-testid="stSidebar"]{background:#0b1320;border-right:1px solid #1d2a3b}
h1,h2,h3{letter-spacing:-.025em} .risk-logo{font-size:23px;font-weight:800;letter-spacing:2px;color:#64d9f5}
.kpi{background:linear-gradient(145deg,#101c2b,#0c1420);border:1px solid #233348;border-radius:13px;padding:16px 18px;min-height:105px}
.kpi-label{font-size:12px;color:#8fa4bd;text-transform:uppercase;letter-spacing:.08em}
.kpi-value{font-size:27px;font-weight:700;margin-top:8px;color:#f1f6fc}
.kpi-note{font-size:12px;color:#8fa4bd;margin-top:3px}
.section{border:1px solid #1d2c40;border-radius:14px;padding:15px;background:#0b1421}
div[data-testid="stMetric"]{background:#0e1928;padding:12px;border:1px solid #233348;border-radius:12px}
.stButton>button{border-radius:8px;border:1px solid #29465e}
</style>
''', unsafe_allow_html=True)
PAGES=["Overview & Market Weather","Stock Outlook","News Intelligence","Historical Risk","Forward Risk","Portfolio X-Ray","Contagion","Stress Testing","Risk Reduction Studio","Model Validation / Backtesting","API & Data Settings"]
if "demo" not in st.session_state: st.session_state.demo=True
if "finnhub_session" not in st.session_state: st.session_state.finnhub_session=""
if "alpha_session" not in st.session_state: st.session_state.alpha_session=""
if "watchlist" not in st.session_state: st.session_state.watchlist=["NVDA","AAPL","MSFT","RELIANCE.NS"]
with st.sidebar:
    st.markdown('<div class="risk-logo">◈ RISKLENS</div><div style="color:#7e93ac;font-size:12px;margin:4px 0 20px">QUANTITATIVE RISK INTELLIGENCE</div>',unsafe_allow_html=True)
    page=st.radio("NAVIGATION",PAGES,label_visibility="collapsed")
    st.divider()
    st.caption("DATA MODE")
    st.session_state.demo=st.toggle("Use demo data",value=st.session_state.demo,help="Synthetic data only; never presented as live market data.")
    st.caption("Models are estimates, not investment advice.")

with st.sidebar:
    st.markdown("**WATCHLIST**")
    for symbol in st.session_state.watchlist: st.caption("◉ "+symbol)
    new=st.text_input("Add ticker",key="new_watch")
    if st.button("Add to watchlist") and new.strip():
        st.session_state.watchlist.append(new.strip().upper()); st.rerun()

st.markdown('<div style="display:flex;justify-content:space-between;align-items:center"><div><span style="color:#64d9f5;font-size:12px;letter-spacing:.12em">MARKET INTELLIGENCE / RISK SYSTEM</span><h1 style="margin:2px 0 0">Risk overview</h1></div><div style="text-align:right;color:#91a4bc;font-size:12px">◉ Session active<br>'+dt.datetime.now().strftime("%d %b %Y · %H:%M")+'</div></div>',unsafe_allow_html=True)
c1,c2,c3,c4=st.columns([1.3,1,1,1])
with c1: exchange=st.selectbox("Exchange / market",["US — Nasdaq / NYSE","India — NSE","India — BSE"])
with c2: ticker=st.text_input("Ticker", "NVDA" if exchange.startswith("US") else "RELIANCE")
with c3: period=st.selectbox("History",["1 year","3 years","5 years","10 years"],index=3)
with c4: refresh=st.button("↻ Refresh data",use_container_width=True)
end=pd.Timestamp.today().normalize(); years={"1 year":1,"3 years":3,"5 years":5,"10 years":10}[period]; start=end-pd.DateOffset(years=years)
ex="US" if exchange.startswith("US") else "NSE" if "NSE" in exchange else "BSE"
try:
    symbol=normalize_ticker(ticker,ex)
    if st.session_state.demo:
        from risklens.data.providers import demo_prices
        df=demo_prices(symbol,days=min(252*years,2520),seed=sum(map(ord,symbol)))
        source="DEMO DATA — synthetic observations"
    else:
        with st.spinner("Requesting historical prices…"):
            df,source=safe_download(symbol,start.date(),(end+pd.Timedelta(days=1)).date())
    returns=df["Return"].dropna().to_numpy(); prices=df["Price"].to_numpy()
    last=float(prices[-1]); annret=annualized_return(returns); vol=annualized_volatility(returns)
    v95,es95=var_es(returns,.95); v99,es99=var_es(returns,.99); dd=max_drawdown(prices); sr=sharpe_ratio(returns)
    error=None
except Exception as exc:
    error=f"{type(exc).__name__}: {exc}"
    df=None
if error:
    st.error("Price data unavailable. "+error)
    st.info("Switch on **Use demo data** in the sidebar, or check the ticker, network and provider availability.")
else:
    st.caption(f"**{symbol}** · {source} · {df.index.min().date()} to {df.index.max().date()} · {len(df):,} observations · fetched/session time {dt.datetime.now().strftime('%H:%M:%S')}")
    if not st.session_state.demo: st.warning("Provider data can be delayed or incomplete. Verify against your broker before acting.")
    if page in ["Overview & Market Weather","Stock Outlook","Historical Risk","Forward Risk"]:
        metrics=[("LATEST PRICE",f"{last:,.2f}",symbol),("ANNUALIZED RETURN",f"{annret:.1%}","Historical estimate"),("ANNUALIZED VOLATILITY",f"{vol:.1%}","252 trading days"),("95% VaR",f"{v95:.2%}","Daily loss estimate")]
        cols=st.columns(4)
        for col,(label,value,note) in zip(cols,metrics):
            col.markdown(f'<div class="kpi"><div class="kpi-label">{label}</div><div class="kpi-value">{value}</div><div class="kpi-note">{note}</div></div>',unsafe_allow_html=True)
        st.write("")
        left,right=st.columns([1.7,1])
        with left:
            st.subheader("Price history & drawdown")
            fig=go.Figure(); fig.add_trace(go.Scatter(x=df.index,y=df.Price,name="Adjusted/close price",line=dict(color="#56c8ed",width=2)))
            fig.update_layout(template="plotly_dark",paper_bgcolor="#0b1421",plot_bgcolor="#0b1421",height=360,margin=dict(l=10,r=10,t=15,b=10),xaxis_title="",yaxis_title="Price")
            st.plotly_chart(fig,use_container_width=True)
            st.subheader("Return distribution")
            hist=go.Figure(go.Histogram(x=returns*100,nbinsx=50,marker_color="#3ca9d1"))
            hist.update_layout(template="plotly_dark",paper_bgcolor="#0b1421",plot_bgcolor="#0b1421",height=250,margin=dict(l=10,r=10,t=15,b=10),xaxis_title="Daily return (%)",yaxis_title="Sessions")
            st.plotly_chart(hist,use_container_width=True)
        with right:
            st.subheader("Risk summary")
            st.metric("95% Expected Shortfall",f"{es95:.2%}")
            st.metric("99% VaR / ES",f"{v99:.2%} / {es99:.2%}")
            st.metric("Maximum drawdown",f"{dd:.1%}")
            st.metric("Sharpe ratio",f"{sr:.2f}" if np.isfinite(sr) else "N/A")
            st.metric("5-Day Worst-Case Bleed",f"{min(1,es95*np.sqrt(5)):.2%}",help="5-day 95% ES approximation using square-root-of-time scaling; not a guaranteed maximum loss.")
            st.info("Market Weather: "+("Stress" if vol>.45 else "Elevated Risk" if vol>.30 else "Normal" if vol>.15 else "Calm")+" — heuristic based on realized annualized volatility, not a crash probability.")
        st.subheader("Forward simulation")
        a,b,c=st.columns(3)
        with a: paths=st.select_slider("Monte Carlo paths",[1000,2500,5000,10000,20000],value=10000)
        with b: horizon=st.slider("Trading-day horizon",1,30,5)
        with c: seed=st.number_input("Random seed",min_value=0,max_value=999999,value=42)
        if st.button("Run Monte Carlo simulation"):
            with st.spinner("Simulating paths…"):
                sims=simulate_gbm(last,returns,horizon,int(paths),int(seed))
                ending=sims[:,-1]; losses=1-ending/last
                st.session_state.sim_summary={"ending":ending,"losses":losses,"horizon":horizon,"paths":paths}
        if "sim_summary" in st.session_state:
            s=st.session_state.sim_summary
            fig=px.histogram(s["ending"],nbins=60,labels={"value":"Simulated ending price"},title=f'{s["paths"]:,} paths · {s["horizon"]}-day ending-price distribution')
            fig.update_layout(template="plotly_dark",paper_bgcolor="#0b1421",plot_bgcolor="#0b1421")
            st.plotly_chart(fig,use_container_width=True)
            q95,tail95=var_es(-s["losses"],.95)
            st.write(f"Simulated 95% loss VaR: **{q95:.2%}** · ES: **{tail95:.2%}**")
            st.caption("GBM baseline calibrated to historical daily mean and volatility. No jump/regime/news overlay unless explicitly selected in a model page.")
    elif page=="Portfolio X-Ray":
        st.subheader("Holdings editor")
        sample=pd.DataFrame([{"ticker":"NVDA","units":10,"price":120.0,"currency":"USD","sector":"Technology"},{"ticker":"AAPL","units":12,"price":220.0,"currency":"USD","sector":"Technology"},{"ticker":"MSFT","units":5,"price":430.0,"currency":"USD","sector":"Technology"}])
        holdings=st.data_editor(sample,num_rows="dynamic",use_container_width=True,key="holdings")
        if len(holdings):
            weighted=portfolio_weights(holdings)
            st.dataframe(weighted,use_container_width=True)
            st.metric("Total value (unconverted currencies)",f"{weighted.value.sum():,.2f}")
            if weighted.currency.nunique()>1: st.error("Multiple currencies detected. FX conversion is required before portfolio aggregation; no conversion is assumed.")
            fig=px.pie(weighted,values="value",names="ticker",hole=.55,title="Position concentration")
            fig.update_layout(template="plotly_dark",paper_bgcolor="#0b1421")
            st.plotly_chart(fig,use_container_width=True)
    elif page=="News Intelligence":
        st.subheader("News Intelligence")
        urls=st.text_area("RSS feed URLs (one per line)","https://feeds.finance.yahoo.com/rss/2.0/headline?s=AAPL&region=US&lang=en-US")
        if st.button("Fetch RSS headlines"):
            with st.spinner("Fetching public RSS feeds…"):
                items,errors=fetch_rss([u.strip() for u in urls.splitlines() if u.strip()])
            if items: st.dataframe(pd.DataFrame(items),use_container_width=True)
            else: st.info("No headlines returned.")
            if errors: st.warning("; ".join(errors))
        st.caption("FinBERT is optional and not loaded by default. Sentiment is contextual, not used to alter simulated jump intensity.")
        st.text_area("Manual news / analyst note",placeholder="Paste a headline or note…")
    elif page=="Contagion":
        st.subheader("Contagion & systemic risk")
        st.info("Contagion score is not computed from a single stock. Supply aligned multivariate returns for dependence, PCA absorption and co-movement analysis.")
        st.metric("Contagion score","Unavailable","Needs multiple aligned assets")
    elif page=="Stress Testing":
        st.subheader("Scenario stress test")
        shock=st.slider("Instant market shock (%)",-60,30,-10)
        vshock=st.slider("Volatility multiplier",1.0,4.0,1.5,.25)
        st.metric("Illustrative price after shock",f"{last*(1+shock/100):,.2f}")
        st.caption(f"Scenario only: {shock}% price shock; volatility multiplier {vshock:.2f}×. Not a forecast.")
    elif page=="Risk Reduction Studio":
        st.subheader("Risk reduction studio")
        st.write("Minimum-variance allocation and CVaR-aware optimization are exposed in the Python module; a valid multi-asset aligned return matrix is required.")
        st.warning("No allocation can guarantee a fixed reduction in risk. Include turnover, transaction costs and real-world constraints before use.")
    elif page=="Model Validation / Backtesting":
        st.subheader("Walk-forward VaR validation")
        from risklens.backtesting.walk_forward import walk_forward_var
        train=st.slider("Training window (sessions)",60,min(500,max(61,len(returns)-1)),min(252,max(61,len(returns)-1)))
        conf=st.selectbox("Confidence",["95%","99%"])
        if st.button("Run walk-forward backtest"):
            try:
                result=walk_forward_var(returns,train,.95 if conf=="95%" else .99)
                st.metric("VaR exceedances",f'{result["exceedances"]} / {len(result["loss"])}')
                st.caption("Expected exceedance rate is approximately 5% or 1% under calibration; small samples have wide uncertainty.")
            except Exception as e: st.error(str(e))
    elif page=="API & Data Settings":
        st.subheader("Provider credentials & connection checks")
        st.warning("Credentials entered here remain in this Streamlit session only. For persistence, use environment variables or Streamlit secrets manager. Never commit .env.")
        fkey=st.text_input("Finnhub API key",value=st.session_state.finnhub_session,type="password")
        akey=st.text_input("Alpha Vantage API key",value=st.session_state.alpha_session,type="password")
        x,y=st.columns(2)
        with x:
            if st.button("Save for this session"): st.session_state.finnhub_session=fkey; st.session_state.alpha_session=akey; st.success("Stored in current session state only.")
            if st.button("Test Finnhub"):
                if not fkey: st.error("Enter a key first.")
                else:
                    ok,msg=test_finnhub(fkey); st.success(msg) if ok else st.error(msg)
        with y:
            if st.button("Test Alpha Vantage"):
                if not akey: st.error("Enter a key first.")
                else:
                    ok,msg=test_alpha_vantage(akey); st.success(msg) if ok else st.error(msg)
        st.write("Environment Finnhub:",mask_secret(get_secret("FINNHUB_API_KEY")))
        st.write("Environment Alpha Vantage:",mask_secret(get_secret("ALPHA_VANTAGE_API_KEY")))
        st.caption("This starter tests provider connectivity but does not yet use those APIs as the primary historical-price backend.")
    else:
        st.subheader(page)
        st.info("This section is scaffolded with its intended function. The core metrics and selected working features are available; advanced calibrations require more validation before production use.")
st.divider()
st.caption("RISKLENS · Educational quantitative risk analysis · No trade execution · Historical risk does not guarantee future outcomes.")
