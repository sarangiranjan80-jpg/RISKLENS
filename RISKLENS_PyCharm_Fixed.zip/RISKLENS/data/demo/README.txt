Demo mode generates deterministic synthetic price histories in memory. These are not real market observations and are clearly labelled in the UI. No live values are fabricated.
